<?php

// session_destroy();
// 設定 Session 的過期時間
require_once 'session_config.php';
session_start();
// session_unset();
// session_destroy();
ob_start(); 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css.css">
    <style>
        p a {
            text-decoration: none;
        }
    </style>
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>

<body>
    <header>
        <div class="container pt-3">
            <div class="row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4 text-center">
                    <p class="h1"><a href="home.php">個人碳排放系統</a></p>
                </div>
                <div class="col-sm-4">
                    <nav>
                        <div class="btn-group">
                            <button class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
                                <?php echo ($result = (isset($_SESSION['login_status']) && $_SESSION['login_status'] == 1)) ? $_SESSION['username'] : '用戶'; ?>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="home.php" class="dropdown-item">碳排放計算</a>
                                <hr class="dropdown-divider">
                                <a href="#" class="dropdown-item login-link">

                                    <?php echo ($result = (isset($_SESSION['login_status']) && $_SESSION['login_status'] == 1)) ? '歷史紀錄' : '登入'; ?>

                                </a>
                                <hr class="dropdown-divider">
                                <a href="#" class="dropdown-item logout-link">登出</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <hr>
    <article>



        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <h2 class="text-center mt-5">Login/Register Form</h2>

                    <div class="text-center mb-3">
                        <button id="login-btn" class="btn btn-primary active">Login</button>
                        <button id="register-btn" class="btn btn-primary">Register</button>
                    </div>

                    <form id="login-form" action="login.php" method="post">
                        <div class="mb-3">
                            <label for="login-gmail" class="form-label">Gmail</label>
                            <input type="text" class="form-control" id="login-gmail" name="gmail" required>
                        </div>

                        <!-- <div class="mb-3">
                            <label for="login-username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="login-username" name="username" required>
                        </div> -->

                        <div class="mb-3">
                            <label for="login-password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="login-password" name="password" required>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Login</button>
                        </div>
                    </form>

                    <form id="register-form" action="#" method="post" style="display: none;">
                        <div class="mb-3">
                            <label for="register-gmail" class="form-label">Gmail</label>
                            <input type="text" class="form-control" id="register-gmail" name="register-gmail" required>
                        </div>

                        <div class="mb-3">
                            <label for="register-username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="register-username" name="register-username"
                                required>
                        </div>

                        <div class="mb-3">
                            <label for="register-password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="register-password" name="register-password"
                                required>
                        </div>

                        <div class="text-center">
                            <button type="submit" id='btn-primary' class="btn btn-primary">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php



        $servename = 'localhost';
        $username = 'root';
        $password = '';
        $dbname = 'carbonemission';
        $conn = new mysqli($servename, $username, $password, $dbname);
        $conn->set_charset("utf8");

        //抓取登入資料
        if (isset($_POST['gmail']) && isset($_POST['password'])) {
            $gmail = $_POST['gmail'];
            // $username = $_POST['username'];
            $username ='';
            $password = $_POST['password'];
            //電子郵件為主鍵，抓起其獲得ID
            $sql = "SELECT ID FROM accountlogin WHERE 電子郵件 LIKE '%{$gmail}%'";
            $result = $conn->query($sql);
            if ($result === false) {
                die("result連結失敗" . $conn->error);
            }
            //抓取username
            $sqlUsername = "SELECT 使用者名稱 FROM accountlogin WHERE 電子郵件 LIKE '%{$gmail}%'";
            $resultUsername = $conn->query($sqlUsername);
            if ($resultUsername->num_rows > 0) {
                
                while ($row = $resultUsername->fetch_assoc()) {
                $username = $row['使用者名稱'];
                }
                // $_SESSION['username'] = $username;
            }
            //如果對應資料>=一筆
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $id = $row['ID'];
                    // echo $id;
                    //更改登入狀態
                    $updateCondition = "UPDATE accountlogin SET 登入狀態=1 where ID='$id'";
                    if ($conn->query($updateCondition) === TRUE) { //登入狀態改成true
                        echo "<div class='container text-center'>登入成功</div>";

                        $_SESSION['login_status'] = 1;
                        // echo $username;
                        $_SESSION['username'] = $username;
                        $_SESSION['ID'] = $id;
                        // echo $_SESSION['ID'];
                        header("Location:home.php");
                        ob_end_flush(); // 结束输出缓冲区并发送输出

                    } else
                        echo "<div class='container text-center'>登入失敗</div>"; //有沒有登入成功
                }
            } else {
                // echo "no relation data";
                echo "<div class='container text-center'>沒有相關資料</div>";
            }

        }



        //抓取註冊資料
        if (isset($_POST['register-gmail']) && isset($_POST['register-username']) && isset($_POST['register-password'])) {
            $registerGmail = $_POST['register-gmail'];
            $registerUsername = $_POST['register-username'];
            $registerPassword = $_POST['register-password'];
            //獲取目前資料數
            $sql = "SELECT * FROM accountlogin";
            $result = $conn->query($sql);
            // echo $result->num_rows."列"; //這是登入內有幾筆資料的意思
            //插入註冊資料
            $row = $result->num_rows;
            $row += 1;
            $registerInsert = "INSERT INTO accountlogin (電子郵件,使用者名稱,密碼,ID) VALUES ('$registerGmail','$registerUsername','$registerPassword','$row')";
            if ($conn->query($registerInsert) === TRUE) {
                // echo "註冊成功";
                echo "<div class='container text-center'>註冊成功</div>";
            } else if ($conn->errno == 1062) {
                // echo "註冊失敗，電子郵件已註冊過";
                echo "<div class='container text-center'>註冊失敗，電子郵件已註冊過</div>";
            } else
                // echo "註冊失敗";
                echo "<div class='container text-center'>註冊失敗</div>";


        }

        ?>

        <!-- 登出警訊 -->
        <div class=" logout-modal" id="logoutModal">
            <div class="logout-modal-content">
                <h2>確定要登出嗎？</h2>
                <div class="logout-modal-buttons">
                    <a href="#" class="btn cancel-btn">取消</a>
                    <!-- <a href="login.php?name=logout" class="btn confirm-btn">確定</a> -->
                    <a href='login.php?logout=1' class="btn confirm-btn">確定</a>
                </div>
            </div>
        </div>
        <?php

        
        if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['logout']) && $_GET['logout'] == 1) {
            // 处理登出逻辑
            // echo $_SESSION["ID"];
            // echo '登出中';
            if (isset($_SESSION['ID'])) {
                $id = $_SESSION['ID'];
                $updateCondition = "UPDATE accountlogin SET 登入狀態 = 0 WHERE ID = '$id'";
                $result = $conn->query($updateCondition);
                if ($result) {
                    // 更新成功
                    // echo '登出成功';
                    // echo "<div class='container text-center'>登出成功</div>";
                    $_SESSION['login_status'] = 0;
                    session_unset();
                    session_destroy();
                } else {
                    // 更新失败
                    // echo "登出失败";
                    // echo "<div class='container text-center'>登出失败</div>";
                }
            }
        }
        
        ?>

    </article>
    <footer>

    </footer>
</body>
<script src='index.js'></script>
<script>
    // 切换登录和注册表单
    const loginBtn = document.getElementById("login-btn");
    console.log(loginBtn);
    const submitBtn = document.querySelector('.btn-primary');

    console.log(submitBtn);
    const registerBtn = document.getElementById("register-btn");
    const loginForm = document.getElementById("login-form");
    const registerForm = document.getElementById("register-form");

    loginBtn.addEventListener("click", () => {
        loginBtn.classList.add("active");
        registerBtn.classList.remove("active");
        loginForm.style.display = "block";
        registerForm.style.display = "none";
    });

    registerBtn.addEventListener("click", () => {
        registerBtn.classList.add("active");
        loginBtn.classList.remove("active");
        registerForm.style.display = "block";
        loginForm.style.display = "none";
    });

    //ID是否存在
    let sessionExists = <?php echo isset($_SESSION['ID']) ? 'true' : 'false'; ?>;

    // 登录链接
    let loginLink = document.querySelector('.login-link');

    // 登录处理
    // submitBtn.addEventListener('click', function (event) {

    //     console.log(123);
    //     if (!sessionExists) {
    //         console.log(123);
    //         // Session不存在，发送登录请求
    //         let xhr = new XMLHttpRequest();
    //         xhr.open('POST', 'login.php', true);
    //         xhr.onreadystatechange = function () {
    //             if (xhr.readyState === 4 && xhr.status === 200) {
    //                 // 登入成功，更新页面上的登录状态
    //                 sessionExists = true;
    //                 let response = xhr.responseText;
    //                 document.getElementById('accountBtn').textContent = response;
    //             }
    //         };

    //         xhr.send();
    //     }
    //     // Session存在，不做任何操作
    //     // 可以根据需要添加其他操作

    // });
    //登出警示
    let logoutLink = document.querySelector('.logout-link');
    let logoutModal = document.getElementById('logoutModal');
    let cancelBtn = document.querySelector('.cancel-btn');
    let confirmBtn = document.querySelector('.confirm-btn');

    logoutLink.addEventListener('click', function (event) {
        if (sessionExists) {
            // session 存在
            // console.log('Session 存在');
            // logoutModal.style.display = 'block';
            let xhr = new XMLHttpRequest();
            xhr.open('GET', 'login.php?logout=1', true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    sessionExists = false;
                    logoutModal.style.display = 'block';
                }
            }
            xhr.send();
        } else {
            // session 不存在
            console.log('Session 不存在');
            alert('您尚未登入');
        }
        event.preventDefault();

    });
    //取消
    cancelBtn.addEventListener('click', function () {
        logoutModal.style.display = 'none';
    });
    confirmBtn.addEventListener('click', function () {
        logoutModal.style.display = 'none';
    });





</script>


</html>