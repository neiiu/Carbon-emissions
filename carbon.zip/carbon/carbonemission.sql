-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2023-06-11 17:52:40
-- 伺服器版本： 10.4.28-MariaDB
-- PHP 版本： 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `carbonemission`
--

-- --------------------------------------------------------

--
-- 資料表結構 `accountlogin`
--

CREATE TABLE `accountlogin` (
  `使用者名稱` varchar(10) NOT NULL,
  `密碼` varchar(20) NOT NULL,
  `登入狀態` tinyint(1) NOT NULL,
  `ID` varchar(4) NOT NULL,
  `電子郵件` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `accountlogin`
--

INSERT INTO `accountlogin` (`使用者名稱`, `密碼`, `登入狀態`, `ID`, `電子郵件`) VALUES
('ann', '1234', 0, '3', 'ann@gmail.com'),
('anna', '1234', 1, '6', 'anna@gmail.com'),
('dobe', '1234', 0, '5', 'dobe@gmail.com'),
('ln', '1234', 1, '7', 'lnn@gmail.com'),
('chen', '1234', 1, '1', 'mandy@gmail.com'),
('ting', '123456789', 1, '4', 'ting@gmail.com'),
('will', '1234', 1, '2', 'will@gmail.com');

-- --------------------------------------------------------

--
-- 資料表結構 `emissiontype`
--

CREATE TABLE `emissiontype` (
  `品項` varchar(20) NOT NULL,
  `碳排放` decimal(10,8) NOT NULL,
  `類型` varchar(10) NOT NULL,
  `單位` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `emissiontype`
--

INSERT INTO `emissiontype` (`品項`, `碳排放`, `類型`, `單位`) VALUES
('⼤雞排', 0.60000000, '飲食', '份'),
('⼿機', 0.00050000, '個⼈3C', '小時'),
('⽕⾞', 0.06000000, '交通⽅式', '公⾥'),
('⽶飯', 0.65000000, '飲食', '碗'),
('⾯紙(10抽)', 0.03000000, '⼀次性⽤品', '包'),
('⾼鐵', 0.04000000, '交通⽅式', '公⾥'),
('⾼麗菜', 0.07000000, '飲食', '盤'),
('⿆當勞⼤薯', 0.15000000, '飲食', '份'),
('免洗筷', 0.02000000, '⼀次性⽤品', '個'),
('公⾞', 0.04000000, '交通⽅式', '公⾥'),
('冷氣', 1.10000000, '家用電器', '⼩時'),
('可樂(鋁罐)', 0.17000000, '飲食', '瓶'),
('吹⾵機', 0.83400000, '家用電器', '⼩時'),
('啤酒(鋁罐)', 0.24000000, '飲食', '瓶'),
('塑膠吸管', 0.00533000, '⼀次性⽤品', '⽀'),
('塑膠杯', 0.00000320, '⼀次性⽤品', '個'),
('塑膠袋', 0.05700000, '⼀次性⽤品', '個'),
('平板', 0.00140000, '個⼈3C', '小時'),
('微波爐', 0.76000000, '家用電器', '⼩時'),
('抽油煙機', 0.22000000, '家用電器', '⼩時'),
('捷運', 0.04000000, '交通⽅式', '公⾥'),
('擦⼿紙', 0.00375000, '⼀次性⽤品', '張'),
('桌上型電腦', 0.07000000, '個⼈3C', '小時'),
('機⾞', 0.06000000, '交通⽅式', '公⾥'),
('汽⾞', 0.24000000, '交通⽅式', '公⾥'),
('洗⾐機', 0.32000000, '家用電器', '⼩時'),
('熱⽔器(60公升)', 1.56000000, '家用電器', '次數'),
('筆記型電腦', 0.01380000, '個⼈3C', '小時'),
('鋁箔裝⿆⾹', 0.16000000, '飲食', '瓶'),
('除濕機', 0.08000000, '家用電器', '⼩時'),
('電⾵扇', 0.02600000, '家用電器', '公斤'),
('電磁爐', 0.76000000, '家用電器', '⼩時'),
('電視', 0.02800000, '家用電器', '⼩時'),
('電鍋', 0.41000000, '家用電器', '次數');

-- --------------------------------------------------------

--
-- 資料表結構 `數據儲存`
--

CREATE TABLE `數據儲存` (
  `ID` varchar(4) NOT NULL,
  `輸入時間` datetime NOT NULL COMMENT '年月日 時分秒',
  `環保分級` varchar(4) NOT NULL COMMENT '環保分級((3)over15低度環保、(2)over10中度環保、(1)lower10高度環保)',
  `總碳排放` double(11,8) NOT NULL COMMENT 'total',
  `樹所需吸收時間` decimal(6,1) NOT NULL COMMENT '上限是99999.99',
  `飲食占比` decimal(5,3) NOT NULL COMMENT '類型',
  `一次性用品占比` decimal(5,3) NOT NULL COMMENT '類型',
  `個人3C占比` decimal(5,3) NOT NULL COMMENT '類型',
  `交通占比` decimal(5,3) NOT NULL COMMENT '類型',
  `家用電器占比` decimal(5,3) NOT NULL COMMENT '類型'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `數據儲存`
--

INSERT INTO `數據儲存` (`ID`, `輸入時間`, `環保分級`, `總碳排放`, `樹所需吸收時間`, `飲食占比`, `一次性用品占比`, `個人3C占比`, `交通占比`, `家用電器占比`) VALUES
('1', '2023-06-02 00:51:54', '1', 0.08000000, 2.4, 0.000, 0.000, 0.000, 1.000, 0.000),
('1', '2023-06-02 00:54:13', '1', 0.01100000, 0.3, 0.000, 0.000, 0.636, 0.364, 0.000),
('1', '2023-06-06 18:48:15', '1', 0.83142064, 25.2, 0.235, 0.000, 0.001, 0.014, 0.751),
('1', '2023-06-07 21:06:38', '1', 3.80690000, 115.4, 0.709, 0.042, 0.002, 0.032, 0.215),
('1', '2023-06-08 16:41:16', '2', 5.18280960, 157.1, 0.050, 0.000, 0.001, 0.015, 0.934),
('7', '2023-06-08 12:51:04', '2', 6.99333000, 211.9, 0.214, 0.010, 0.014, 0.004, 0.757);

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `accountlogin`
--
ALTER TABLE `accountlogin`
  ADD PRIMARY KEY (`電子郵件`);

--
-- 資料表索引 `emissiontype`
--
ALTER TABLE `emissiontype`
  ADD PRIMARY KEY (`品項`,`類型`);

--
-- 資料表索引 `數據儲存`
--
ALTER TABLE `數據儲存`
  ADD PRIMARY KEY (`ID`,`輸入時間`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
