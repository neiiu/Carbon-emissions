<?php
//連線對象
$servename = 'localhost';
$username = 'root';
$password = '';
$dbname = 'carbonemission';
//進行連線
$conn = new mysqli($servename, $username, $password, $dbname);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("連線失敗: " . $conn->connect_error);
} else {
    echo "連線成功: " . $dbname;
}

// 執行查詢，獲取數據
$sql = "SELECT * FROM 數據儲存";
$result = $conn->query($sql);

// 檢查是否有數據返回
if ($result->num_rows > 0) {
    $data = array();

    // 將數據存入關聯數組
    while ($row = $result->fetch_assoc()) {
        $data[] = array(
            "foodP" => $row["飲食占比"],
            "OnceP" => $row["一次性用品占比"],
            "ThreeP" => $row["個人3C占比"],
            "TrafficP" => $row["交通占比"],
            "EleP" => $row["家用電器占比"]
        );
        // 將數據轉換為JSON格式
        $json_data = json_encode($data);
        echo $json_data;
    }


} else {
    echo "沒有數據";
}

?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="css.css"> -->
    <style>
        p a {
            text-decoration: none;
        }
    </style>
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css.css">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>

<body>
    <header>
        <div class="container pt-3">
            <div class="row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4 text-center">
                    <p class="h1"><a href="home.php">個人碳排放系統</a></p>
                </div>
                <div class="col-sm-4">
                    <nav>
                        <div class="btn-group">
                            <button class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
                                <?php echo ($result = (isset($_SESSION['login_status']) && $_SESSION['login_status'] == 1)) ? $_SESSION['userName'] : '用戶'; ?>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="home.php" class="dropdown-item">碳排放計算</a>
                                <hr class="dropdown-divider">
                                <a href="#" class="dropdown-item logout-link">登出</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <div id="chartContainer"></div>
</body>
<script>
    //繪製圓餅圖
    // 将 JSON 字符串转换为 JavaScript 对象
    var Data = <?php echo $jsonData; ?>;

    // 在控制台打印数组内容
    console.log(Data);
    var pieChartData = [
        { label: "飲食: ", value: Data[0] },
        { label: "一次性用品: ", value: Data[1] },
        { label: "個人3C: ", value: Data[2] },
        { label: "交通方式: ", value: Data[3] },
        { label: "家用電器: ", value: Data[4] }
    ];
    console.log(pieChartData);

    // var colors = ["#B0E0E6", "#87CEEB", "#B0C4DE", "#4682B4", "#4169E1"];
    var colors = ["#DF5459", "#ECD76C", "#B5E46E", "#59A0D7", "#2670A9"];
    var chart = new PieChart("chartContainer", pieChartData, colors);
    chart.draw();

    function PieChart(containerId, data, colors) {
        this.containerId = containerId;
        this.data = data;
        this.colors = colors;

        this.draw = function () {
            var container = document.getElementById(this.containerId);
            // 移除先前創建的 canvas 元素
            var existingCanvas = container.getElementsByTagName("canvas");
            if (existingCanvas.length > 0) {
                container.removeChild(existingCanvas[0]);
            }

            // 創建新的 canvas 元素
            var canvas = document.createElement("canvas");
            container.appendChild(canvas);

            var ctx = canvas.getContext("2d");
            var centerX = canvas.width / 2;
            var centerY = canvas.height / 2;
            var radius = Math.min(centerX, centerY);
            var startAngle = 0;

            var totalValue = this.data.reduce(function (sum, dataPoint) {
                return sum + dataPoint.value;
            }, 0);

            this.data.forEach(function (dataPoint, index) {
                var endAngle = startAngle + (Math.PI * 2 * dataPoint.value / totalValue);

                ctx.beginPath();
                ctx.moveTo(centerX, centerY);
                ctx.arc(centerX, centerY, radius, startAngle, endAngle);
                ctx.closePath();

                ctx.fillStyle = colors[index % colors.length];
                ctx.fill();

                startAngle = endAngle;
            });

            var labelContainer = document.createElement("div");
            labelContainer.classList.add("label-container");
            container.appendChild(labelContainer);

            this.data.forEach(function (dataPoint, index) {
                var label = document.createElement("div");
                label.classList.add("label");

                var colorBox = document.createElement("div");
                colorBox.classList.add("color-box");
                colorBox.style.backgroundColor = colors[index % colors.length];

                var labelText = document.createElement("span");
                labelText.innerText = dataPoint.label;

                // var percentage = ((dataPoint.value / totalValue) * 100).toFixed(1) + "%";
                var percentage = (dataPoint.value * 100).toFixed(1) + "%";
                console.log(percentage);
                var percentageText = document.createElement("span");
                console.log(percentageText);
                percentageText.innerText = percentage;

                label.appendChild(colorBox);
                label.appendChild(labelText);
                label.appendChild(percentageText);

                labelContainer.appendChild(label);
            });
        };
    }
</script>

</html>