<?php
require_once 'session_config.php';
session_start();
// session_destroy();
//連線對象
// $servename = 'localhost';
// $username = 'root';
// $password = '';
// $dbname = 'carbonemission';
//進行連線
// $conn = new mysqli($servename, $username, $password, $dbname);
// $conn->set_charset("utf8");

// if ($conn->connect_error) {
//     die("連線失敗: " . $conn->connect_error);
// } else {
//     echo "連線成功: " . $dbname;
// }
$Count = 0;
// $conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="css.css"> -->
    <style>
        /* 表格 */
        thead {
            background-color: #afcef8;
            /* color:white; */
        }

        tbody tr:nth-child(odd) {
            background-color: rgba(194, 212, 238, 0.8);
        }

        /*  */
        .logout-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(85, 105, 136, 0.8);
        }

        .logout-modal-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .logout-modal h2 {
            margin-top: 0;
        }

        .logout-modal-buttons {
            margin-top: 20px;
        }

        .logout-modal-buttons .btn {
            display: inline-block;
            padding: 8px 16px;
            margin: 0 5px;
            text-decoration: none;
            color: #fff;
            background-color: rgba(85, 105, 136, 0.8);
            border-radius: 3px;
        }

        .logout-modal-buttons .btn:hover {
            background-color: rgba(85, 105, 136, 1);
        }
    </style>
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>
<!-- 類別 -->
<!-- 資料量越來越多 -->
<!-- 系統化管理 -->
<!-- 內容物改變後會影響後續(要處理) -->
<body>
    <?php
    // 飲食
    $foodName = array('⿆當勞⼤薯', '⽶飯', '⾼麗菜', '⼤雞排', '鋁箔裝⿆⾹', '啤酒(鋁罐)', '可樂(鋁罐)');
    $foodUnit = array('份', '碗', '盤', '份', '瓶', '瓶', '瓶');
    // 一次性物品
    $disposableName = array('塑膠吸管', '免洗筷', '塑膠杯', '塑膠袋', '擦⼿紙', '⾯紙(10抽)');
    $disposabledUnit = array('⽀', '個', '個', '個', '張', '包');
    // 個人3C
    $threeCName = array('桌上型電腦', '筆記型電腦', '平板', '⼿機');
    $threeCUnit = array('⼩時', '⼩時', '⼩時', '⼩時');
    //交通方式
    $TrafficName = array('捷運', '公⾞', '汽⾞', '機⾞', '⾼鐵', '⽕⾞');
    $TrafficUnit = array('公⾥', '公⾥', '公⾥', '公⾥', '公⾥', '公⾥');
    //家用電器
    $EleName = array('冷氣', '熱⽔器(60公升) ', '電鍋', '除濕機', '吹⾵機', '電視', '電⾵扇', '洗⾐機', '抽油煙機', '微波爐', '電磁爐');
    $EleUnit = array('⼩時', '次數', '次數', '⼩時', '⼩時', '⼩時', '⼩時', '⼩時', '⼩時', '⼩時', '⼩時');
    // 加入新東西的第一個更改區域
    $totalName = array($foodName, $disposableName, $threeCName, $TrafficName, $EleName);
    // for ($i = 0; $i < count($totalName); $i++) {
    //     for ($j = 0; $j < count($totalName[$i]); $j++) {
    //         echo $totalName[$i][$j];
    //     }
    // }
    $totalUnit = array($foodUnit, $disposabledUnit, $threeCUnit, $TrafficUnit, $EleUnit);
    //
    ?>
    <header>
        <div class="container pt-3">
            <div class="row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4 text-center">
                    <p class="h1">個人碳排放系統</p>
                </div>
                <div class="col-sm-4">
                    <nav>
                        <div class="btn-group">
                            <button class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
                                <?php echo ($result = (isset($_SESSION['login_status']) && $_SESSION['login_status'] == 1)) ? $_SESSION['username'] : '用戶'; ?>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <!-- <a href="#" class="dropdown-item">碳排放計算</a>
                                <hr class="dropdown-divider"> -->
                                <a href="#" class="dropdown-item" id="account-link">
                                    <?php echo ($result = (isset($_SESSION['login_status']) && $_SESSION['login_status'] == 1)) ? '歷史紀錄' : '登入'; ?>
                                </a>
                                <hr class="dropdown-divider">
                                <a href="#" class="dropdown-item logout-link">登出</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <article>
        <hr>
        <form action="getForm.php" method="post">
            <div class="container">
                <div class="row justify-content-end">
                    <div class="col-sm-2">
                        <input type="reset" class="btn btn-primary d-block mb-3" value="重置">
                        <input type="submit" class="btn btn-primary d-block" name='submit'
                            value="<?php echo ($result = (isset($_SESSION['login_status']) && $_SESSION['login_status'] == 1)) ? '送出' : '請先登入'; ?>">
                    </div>
                </div>
                <?php
                echo '<div class="container row">';
                echo '<div class="col-sm-1">';
                echo '</div>';
                for ($i = 0; $i < count($totalName); $i++) {
                    echo '<div class="col-sm-2">';
                    // img
                    // 加入新東西的第二個更改區域
                    $totalImg = array('高麗菜.png', '湯匙.png', 'computer.png', 'car.png', '微波爐.png');
                    echo '<img src="' . $totalImg[$Count] . '" alt="" class="rounded mx-auto d-block" width="200px">';
                    // form
                    echo '<table class="table table-striped table-bordered">';
                    echo '<thead>';
                    // 加入新東西的第三個更改區域
                    $totalTitle = array('飲食', '一次性用品', '個人3C', '交通方式', '家用電器');
                    echo "<th>{$totalTitle[$Count]}</th>";
                    echo '<th>數量</th>';
                    echo '<th>單位</th>';
                    echo '</thead>';
                    echo '<tbody>';
                    for ($j = 0; $j < count($totalName[$i]); $j++) {
                        echo '<tr>';
                        echo '<td>' . $totalName[$Count][$j] . '</td>';
                        echo '<td><input type="number" min="0" max="10000" step="0.1" class="form-control" name="  inputname[' . $totalName[$Count][$j] . ']  "></td>';
                        echo '<td>' . $totalUnit[$Count][$j] . '</td>';
                        echo '</tr>';
                    }
                    $Count++;
                    echo '</tbody>';
                    echo '</table>';
                    echo '</div>';
                }
                echo '</div>';
                echo '<div class="col-sm-1">';
                echo '</div>';
                ?>
            </div>
        </form>
        <!-- 登出警訊 -->
        <div class=" logout-modal" id="logoutModal">
            <div class="logout-modal-content">
                <h2>確定要登出嗎？</h2>
                <div class="logout-modal-buttons">
                    <a href="#" class="btn cancel-btn">取消</a>
                    <!-- <a href="login.php?name=logout" class="btn confirm-btn">確定</a> -->
                    <a href='login.php?logout=1' class="btn confirm-btn">確定</a>
                </div>
            </div>
        </div>
        <?php

        if (isset($_GET['logout']) && $_GET['logout'] == 1) {
            // header("Location: home.php");
            session_unset();
            session_destroy();
        }

        ?>
    </article>

</body>
<script>
    

    //ID是否存在
    let sessionExists = <?php echo isset($_SESSION['ID']) ? 'true' : 'false'; ?>;


    //登出警示
    let logoutLink = document.querySelector('.logout-link');
    let logoutModal = document.getElementById('logoutModal');
    let cancelBtn = document.querySelector('.cancel-btn');
    let confirmBtn = document.querySelector('.confirm-btn');
    logoutLink.addEventListener('click', function (event) {
        if (sessionExists) {
            // session 存在
            // console.log('Session 存在');
            // logoutModal.style.display = 'block';
            //session存在，發送AJAX請求
            let xhr = new XMLHttpRequest();
            xhr.open('GET','login.php?logout=1',true);
            xhr.onload = function(){
                if(xhr.status === 200){
                    sessionExists = false;
                    logoutModal.style.display = 'block';
                }
            }
            xhr.send();
        } else {
            // session 不存在
            console.log('Session 不存在');
            alert('您尚未登入');
        }
          event.preventDefault();

    });
    //取消
    cancelBtn.addEventListener('click', function () {
        logoutModal.style.display = 'none';
    });
    confirmBtn.addEventListener('click', function () {
        logoutModal.style.display = 'none';
    });


    //控制是去登入還是去歷史紀錄
    let accountLink = document.getElementById('account-link');

    // 綁定點擊事件處理程式 
    accountLink.addEventListener('click', function(event) {
      event.preventDefault(); // 防止點擊後立即執行預設的連結行為

      // 檢查 Session 中的登入狀態
      let loginStatus = <?php echo isset($_SESSION['login_status']) && $_SESSION['login_status'] == 1 ? 'true' : 'false'; ?>;

      if (loginStatus) {
        // 登入狀態為已登入，導向歷史紀錄頁面
        window.location.href = 'account_info.php';
      } else {
        // 登入狀態為未登入，導向登入頁面
        window.location.href = 'login.php';
      }  
    });
</script>
<!-- <script src="index.js"></script> -->

</html>