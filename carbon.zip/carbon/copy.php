// //食物output
// for ($i = 0; $i < count($foodName); $i++) {
//     $food = $foodName[$i];
//     if (isset($_POST[$food]) && $_POST[$food] > 0) {
//         $quantity = $_POST[$food];
//         echo "飲食: " . $food . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }
// //一次性用品output
// for ($i = 0; $i < count($disposableName); $i++) {
//     $disposable = $disposableName[$i];
//     if (isset($_POST[$disposable]) && $_POST[$disposable] > 0) {
//         $quantity = $_POST[$disposable];
//         echo "一次性用品: " . $disposable . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }
// // 個人3C
// for ($i = 0; $i < count($threeCName); $i++) {
//     $threeC = $threeCName[$i];
//     if (isset($_POST[$threeC]) && $_POST[$threeC] > 0) {
//         $quantity = $_POST[$threeC];
//         echo "個人3C: " . $threeC . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }
// //交通方式
// for ($i = 0; $i < count($TrafficName); $i++) {
//     $Traffic = $TrafficName[$i];
//     if (isset($_POST[$Traffic]) && $_POST[$Traffic] > 0) {
//         $quantity = $_POST[$Traffic];
//         echo "交通方式: " . $Traffic . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }
// //家用電器
// for ($i = 0; $i < count($EleName); $i++) {
//     $Ele = $EleName[$i];
//     if (isset($_POST[$Ele]) && $_POST[$Ele] > 0) {
//         $quantity = $_POST[$Ele];
//         echo "家用電器: " . $Ele . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }