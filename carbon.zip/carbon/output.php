<?php
// 執行程式碼並捕獲輸出結果
ob_start();
include 'getForm.php'; // 將 "your_code.php" 替換為您的實際程式碼檔案

$output = ob_get_clean();

// 將輸出結果寫入到檔案中
$file = fopen('output.html', 'w');
fwrite($file, $output);
fclose($file);

echo '已儲存程式碼輸出結果到 output.html 檔案中。';
?>
