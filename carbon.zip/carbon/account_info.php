<?php
require_once 'session_config.php';
session_start();
?>

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- <link rel="stylesheet" href="css.css"> -->
  <style>
    p a {
      text-decoration: none;
    }

    .first-column {
      background-color: #F0F0F0;
      /* 第一列的背景颜色 */
    }

    .last-four-columns {
      background-color: #E0E0E0;
      /* 最后四列的背景颜色 */
    }

    td {
      padding: 8px;
      border: 1px solid #ddd;
    }

    th {
      padding: 8px;
      border: 1px solid #ddd;
    }

    .order {

      cursor: pointer;
    }

    .border1 {
      /* color: #6495ED; */
      border-radius: 10px;
      border: 1px solid #6495ED;
      padding: 20px;
      border-width: 3;
    }

    /* .table-container {
      width: 100%;
    } */
  </style>
  <!-- Latest compiled and minified CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- <link rel="stylesheet" href="css.css"> -->
  <!-- Latest compiled JavaScript -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <title>Document</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
  <!-- nav -->
  <header>
    <div class="container pt-3">
      <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4 text-center">
          <p class="h1"><a href="home.php">個人碳排放系統</a></p>
        </div>
        <div class="col-sm-4">
          <nav>
            <div class="conatiner btn-group">
              <!-- <button class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown"> -->
              <button class="btn btn-primary">
                <?php echo ($result = (isset($_SESSION['login_status']) && $_SESSION['login_status'] == 1)) ? $_SESSION['username'] : '用戶'; ?>
              </button>
              <!-- <div class="dropdown-menu dropdown-menu-end">
                <a href="home.php" class="dropdown-item">碳排放計算</a> -->
              <!-- <hr class="dropdown-divider"> -->
              <!-- <a href="#" class="dropdown-item logout-link">登出</a> -->
            </div>
        </div>
        </nav>
      </div>
    </div>
    </div>
  </header>
  <!-- nav -->
  <hr>
  <h3 class='container text-center'>查詢歷史</h3>
  <div class='container'>
    <div class='row'>
      <div class="col-sm-3 border1">
        <div id="pieChartContainer">
          <canvas id="pieChart"></canvas>
        </div>
      </div>
      <!-- connection -->
      <?php
      //連線對象
      $servename = 'localhost';
      $username = 'root';
      $password = '';
      $dbname = 'carbonemission';
      //進行連線
      $conn = new mysqli($servename, $username, $password, $dbname);
      $conn->set_charset("utf8");

      if ($conn->connect_error) {
        die("連線失敗: " . $conn->connect_error);
      } else {
        // echo "連線成功: " . $dbname;
      }

      // chat
// 获取当前页码
      $current_page = isset($_GET['page']) ? $_GET['page'] : 1;

      // 每页显示的记录数
      $records_per_page = 10;

      // 计算偏移量
      $offset = ($current_page - 1) * $records_per_page;



      // 執行查詢，獲取數據
// $sql = "SELECT * FROM 數據儲存";\
      $id = $_SESSION['ID'];
      // echo $_SESSION['ID'];
      $sql = "SELECT 輸入時間, 環保分級, 總碳排放, 樹所需吸收時間, 飲食占比, 一次性用品占比, 個人3C占比, 交通占比, 家用電器占比 FROM 數據儲存 WHERE ID=$id ORDER BY 輸入時間 DESC LIMIT $offset, $records_per_page";
      $result = $conn->query($sql);
      // 计算总记录数
      $total_records_sql = "SELECT COUNT(*) AS total FROM 數據儲存 WHERE ID=$id";
      $total_records_result = $conn->query($total_records_sql);
      $total_records = $total_records_result->fetch_assoc()['total'];

      // 计算总页数
      $total_pages = ceil($total_records / $records_per_page);
      echo "<div class='col-sm-9'>";
      // 显示分页链接
      echo "<div class='pagination container text-center' style='padding-left:80%;'>";
      for ($i = 1; $i <= $total_pages; $i++) {
        echo "<a href='account_info.php?page=$i'>$i</a>";
        if ($i + 1 <= $total_pages)
          echo '-';
      }
      echo "</div>";

      // 檢查是否有數據返回
      
      // 输出表格
      
      if ($result->num_rows > 0) {

        echo "<div class='container'>";
        echo '<table id="data-table" style="border-collapse: collapse; width: 100%;">';
        echo '<thead>';
        echo '<tr style="background-color: #BFEFFF;">';
        echo '<th>輸入時間</th>';
        echo '<th>環保分級</th>';
        echo '<th>總碳排放</th>';
        echo '<th>樹所需吸收時間</th>';
        echo '<th>飲食占比</th>';
        echo '<th>一次性用品占比</th>';
        echo '<th>個人3C占比</th>';
        echo '<th>交通占比</th>';
        echo '<th>家用電器占比</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        // 输出数据行
        $i = 0;
        while ($row = $result->fetch_assoc()) {
          $rowClass = 'order-' . $i;
          echo '<tr class="order ' . $rowClass . '">';
          echo '<td class="first-column" style="color:blue;">' . $row["輸入時間"] . '</td>';
          // echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $row["環保分級"] . '</td>';
          switch ($row["環保分級"]) {
            case 1:
              // echo "<h1>你好環保！超讚！</h1>";
              echo '<td>' . $row["環保分級"] . ' :你好環保！超讚！</td>';
              // $dynamicContent .= "<h1>你好環保！超讚！</h1>";
              break;
            case 2:
              echo '<td>' . $row["環保分級"] . ' :很棒了！可以再更環保！</td>';
              // $dynamicContent .= "<h1>很棒了！可以再更環保！</h1>";
              break;
            case 3:
              // echo "你超不環保！跟地球說對不起！！";
              echo '<td>' . $row["環保分級"] . ' :你超不環保！跟地球說對不起！！</td>';
              // $dynamicContent .= "<h1>你超不環保！跟地球說對不起！！</h1>";
              break;
          }

          echo '<td>' . $row["總碳排放"] . '</td>';
          echo '<td>' . $row["樹所需吸收時間"] . '</td>';
          echo '<td class="last-four-columns">' . $row["飲食占比"] . '</td>';
          echo '<td class="last-four-columns">' . $row["一次性用品占比"] . '</td>';
          echo '<td class="last-four-columns">' . $row["個人3C占比"] . '</td>';
          echo '<td class="last-four-columns">' . $row["交通占比"] . '</td>';
          echo '<td class="last-four-columns">' . $row["家用電器占比"] . '</td>';
          echo '</tr>';
          $i++;
        }

        echo '</tbody>';
        echo '</table>';
        echo '</div>';
      } else {
        echo "<div class='container text-center'>暫無資料</div>";
      }

      ?>
      <br>
    </div>
  </div>
  </div>
</body>
<script>
  // 获取所有具有 order 类的表格行元素
  const orderRows = document.querySelectorAll('.order');

  // 遍历每个表格行并添加点击事件监听器
  orderRows.forEach(row => {
    row.addEventListener('click', handleRowClick);
  });

  // 点击事件处理函数
  function handleRowClick(event) {
    // 获取被点击的表格行的标识符
    const rowId = event.currentTarget.className.split(' ')[1];

    // 在此处执行您希望在点击表格行时执行的操作
    // 可以发送AJAX请求到后端，处理其他逻辑等
    console.log('Clicked row ID:', rowId);
  }
  var food = 0;
  var once = 0;
  var p3C = 0;
  var traffic = 0;
  var ele = 0;
  var pieChart = null;
  document.addEventListener("DOMContentLoaded", function () {
    // 获取表格元素
    var table = document.getElementById("data-table");

    // 为表格每一行绑定点击事件
    var rows = table.getElementsByTagName("tr");
    for (var i = 0; i < rows.length; i++) {
      rows[i].addEventListener("click", function () {
        // 获取所点击行的数据
        var rowData = this.cells;
        // console.log(rowData[0].innerText);
        // food = parseInt(rowData[4].innerText);
        // once = parseInt(rowData[5].innerText);
        // p3C = parseInt(rowData[6].innerText);
        // traffic = parseInt(rowData[7].innerText);
        // ele = parseInt(rowData[8].innerText);
        food = (rowData[4].innerText);
        once = (rowData[5].innerText);
        p3C = (rowData[6].innerText);
        traffic = (rowData[7].innerText);
        ele = (rowData[8].innerText);
        // 输出所点击行的数据
        for (var j = 0; j < rowData.length; j++) {
          console.log(j + ": " + rowData[j].innerText);
        }

        // 销毁之前的饼图实例
        if (pieChart) {
          pieChart.destroy();
        }

        // 绘制饼图
        drawPieChart();
      });
    }
  });

  function drawPieChart() {
    // 获取绘图区域的canvas元素
    var canvas = document.getElementById('pieChart');

    // 定义数据
    var data = {
      labels: ['飲食', '一次性用品', '個人3C', '交通', '家用電器'],
      datasets: [{
        data: [food, once, p3C, traffic, ele], // 数据值
        backgroundColor: ['red', 'green', 'blue', 'yellow', 'pink'], // 每个数据项的颜色
      }]
    };

    // 绘制饼图
    pieChart = new Chart(canvas, {
      type: 'pie',
      data: data,
    });
  }

</script>

</html>