<?php
$expiration = 60 * 60; // 5 分鐘，以秒為單位
session_set_cookie_params($expiration);
// session_start();
?>