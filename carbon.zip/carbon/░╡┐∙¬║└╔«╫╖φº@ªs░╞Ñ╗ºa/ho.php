<?php
//連線對象
$servename = 'localhost';
$username = 'root';
$password = '';
$dbname = 'carbonemission';
//進行連線
$conn = new mysqli($servename, $username, $password, $dbname);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("連線失敗: " . $conn->connect_error);
} else {
    echo "連線成功: " . $dbname;
}
$Count = 0;
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>

<body>
    <?php
    $foodName = array('⿆當勞⼤薯', '⽶飯', '⾼麗菜', '⼤雞排', '鋁箔裝⿆⾹', '啤酒(鋁罐)', '可樂(鋁罐)');
    $foodUnit = array('份', '碗', '盤', '份', '瓶', '瓶', '瓶');
    $disposableName = array('塑膠吸管', '免洗筷', '塑膠杯', '塑膠袋', '擦⼿紙', '⾯紙(10抽)');
    $disposabledUnit = array('⽀', '個', '個', '個', '張', '包');
    $totalName = array($foodName, $disposableName);
    for ($i = 0; $i < count($totalName); $i++) {
        for ($j = 0; $j < count($totalName[$i]); $j++) {
            echo $totalName[$i][$j];
        }
    }
    $totalUnit = array($foodUnit, $disposabledUnit);
    ?>
    <header>
        <div class="container pt-3">
            <p class="h1">個人碳排放系統</p>
        </div>
        <nav class='container'>
            <div class='btn-group'>
                <button class='btn btn-primary dropdown-toggle' data-bs-toggle='dropdown'>訪客</button>
                <div class='dropdown-menu'>
                    <a href="#" class='dropdown-item'>碳排放計算</a>
                    <a href="#" class='dropdown-item'>歷史數據</a>
                    <a href="#" class='dropdown-item'>登出</a>
                </div>

            </div>
        </nav>
    </header>
    <article>
        <form action="test.php" method="post">
        <?php
        echo '<div class="container row">';
        for ($i = 0; $i < count($totalName); $i++) {
            echo '<div class="col-sm-3">';
            // img
            $totalImg = array('高麗菜.png', '湯匙.png');
            echo '<img src="' . $totalImg[$Count] . '" alt="" class="rounded mx-auto d-block" width="250px">';
            // form
            // echo '<form action="test.php" method="post">';
            echo '<table class="table table-striped table-bordered">';
            echo '<thead>';
            $totalTitle = array('飲食', '一次性用品');
            echo "<th>{$totalTitle[$Count]}</th>";
            echo '<th>數量</th>';
            echo '<th>單位</th>';
            echo '</thead>';
            echo '<tbody>';
            for ($j = 0; $j < count($totalName[$i]); $j++) {
                echo '<tr>';
                echo '<td>' . $totalName[$Count][$j] . '</td>';
                echo '<td><input type="number" class="form-control" name="' . $totalName[$i][$j] . '"></td>';
                echo '<td>' . $totalUnit[$Count][$j] . '</td>';
                echo '</tr>';
            }
            $Count++;
            echo '</tbody>';
            echo '</table>';
            // echo '</form>';
            echo '</div>';
        }
        echo '</div>';
        ?>
        <input type="submit" name='submit'>
        </form>
    </article>

</body>
<script>
    document.getElementsByName('submit').addEventListening('click',function(){
        alert('123')
    });
    
</script>
</html>
