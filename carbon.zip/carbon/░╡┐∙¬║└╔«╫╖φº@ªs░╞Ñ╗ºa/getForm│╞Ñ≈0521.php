<?php
//連線對象
$servename = 'localhost';
$username = 'root';
$password = '';
$dbname = 'carbonemission';
//進行連線
$conn = new mysqli($servename, $username, $password, $dbname);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("連線失敗: " . $conn->connect_error);
} else {
    echo "連線成功: " . $dbname . "<br>";
}



//關閉連線
// $conn->close();
?>

<?php
// 飲食
$foodName = array('⿆當勞⼤薯', '⽶飯', '⾼麗菜', '⼤雞排', '鋁箔裝⿆⾹', '啤酒(鋁罐)', '可樂(鋁罐)');
$foodUnit = array('份', '碗', '盤', '份', '瓶', '瓶', '瓶');
// 一次性物品
$disposableName = array('塑膠吸管', '免洗筷', '塑膠杯', '塑膠袋', '擦⼿紙', '⾯紙(10抽)');
$disposabledUnit = array('⽀', '個', '個', '個', '張', '包');
// 個人3C
$threeCName = array('桌上型電腦', '筆記型電腦', '平板', '⼿機');
$threeCUnit = array('⼩時', '⼩時', '⼩時', '⼩時');
//交通方式
$TrafficName = array('捷運', '公⾞', '汽⾞', '機⾞', '⾼鐵', '⽕⾞');
$TrafficUnit = array('公⾥', '公⾥', '公⾥', '公⾥', '公⾥', '公⾥');
//家用電器
$EleName = array('冷氣', '熱⽔器(60公升) ', '電鍋', '除濕機', '吹⾵機', '電視', '電⾵扇(落地)', '洗⾐機', '抽油煙機', '微波爐', '電磁爐');
$EleUnit = array('⼩時', '次數', '次數', '⼩時', '⼩時', '⼩時', '⼩時', '⼩時', '⼩時', '⼩時', '⼩時');

$totalTitle = array('飲食', '一次性用品', '個人3C', '交通方式', '家用電器');
//初始變數
$totalEmission = 0; //總排放量
$foodEmission = 0;
$OnceEmission = 0;
$threeCEmission = 0;
$trafficEmission = 0;
$EleEmission = 0;
$emissionRange = 0;

if (isset($_POST['inputname'])&& isset($_SESSION['ID']) ) {
    // print_r($_POST['inputname']);
    $input_numbers = $_POST['inputname'];
    // 過濾大於 0 的數字
    $positive_numbers = array_filter($input_numbers, function ($num) {
        return $num > 0;
    });

    // 輸出結果
    // print_r($positive_numbers);
    // 檢查且準備存入資料庫
    for ($i = 0; $i < count($positive_numbers); $i++) {
        $getResult = array_keys($positive_numbers)[$i];
        $getValue = $positive_numbers[$getResult];
        //判斷類別
        if (in_array($getResult, $foodName)) {
            $getCategory = $totalTitle[0]; //飲食
        } else if (in_array($getResult, $disposableName)) {
            $getCategory = $totalTitle[1]; //一次性用品
        } else if (in_array($getResult, $threeCName)) {
            $getCategory = $totalTitle[2]; //個人3C
        } else if (in_array($getResult, $TrafficName)) {
            $getCategory = $totalTitle[3]; //交通方式
        } else if (in_array($getResult, $EleName)) {
            $getCategory = $totalTitle[4]; //家用電器
        } else
            echo "其餘類別";
        echo $getResult . "<br>";
        echo $getValue . "<br>";
        echo $getCategory . "<br>";
        //查詢碳排放量
        $sql = "SELECT 碳排放 FROM emissiontype WHERE 品項 = '$getResult'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $emission = $row['碳排放'];
                switch ($getCategory) {
                    case $totalTitle[0]:
                        $foodEmission += (double) ($emission * $getValue);
                        echo "排放量" . $emission . "<br>";
                        $totalEmission += (double) ($emission * $getValue);
                        break;
                    case $totalTitle[1]:
                        $OnceEmission += (double) ($emission * $getValue);
                        echo "排放量" . $emission . "<br>";
                        $totalEmission += (double) ($emission * $getValue);
                        break;
                    case $totalTitle[2]:
                        $threeCEmission += (double) ($emission * $getValue);
                        echo "排放量" . $emission . "<br>";
                        $totalEmission += (double) ($emission * $getValue);
                        break;
                    case $totalTitle[3]:
                        $trafficEmission += (double) ($emission * $getValue);
                        echo "排放量" . $emission . "<br>";
                        $totalEmission += (double) ($emission * $getValue);
                        break;
                    case $totalTitle[4]:
                        $EleEmission += (double) ($emission * $getValue);
                        echo "排放量" . $emission . "<br>";
                        $totalEmission += (double) ($emission * $getValue);
                        break;
                }

            }
        }
        if (!$result) {
            echo "SQL 查詢錯誤：" . mysqli_error($conn);
        }


    }
    //確認每個類別的排放量
    echo $foodEmission . "<br>";
    echo $OnceEmission . "<br>";
    echo $threeCEmission . "<br>";
    echo $trafficEmission . "<br>";
    echo $EleEmission . "<br>";
    //計算占比
    $foodProportion = $foodEmission / $totalEmission;
    $OnceProportion = $OnceEmission / $totalEmission;
    $threeCProportion = $threeCEmission / $totalEmission;
    $trafficProportion = $trafficEmission / $totalEmission;
    $EleProportion = $EleEmission / $totalEmission;
    //檢查占比
    echo $foodProportion."<br>";
    echo $OnceProportion."<br>";
    echo $threeCProportion."<br>";
    echo $trafficProportion."<br>";
    echo $EleProportion."<br>";
    $totalProportion = $foodProportion +$OnceProportion +$threeCProportion +$trafficProportion +$EleProportion ;
    echo "總比例: ".$totalProportion."<br>";
    echo "總排放量:" . $totalEmission . "<br>";

    //計算樹吸收時間
    $assimilateDays = round($totalEmission/0.033,2);
    echo "樹所需吸收天數".$assimilateDays."<br>";
    //環保分級
    if($totalEmission>=0&&$totalEmission<10){
        $emissionRange = 1;
    }else if($totalEmission<15){
        $emissionRange = 2;
    }
    else if($totalEmission>15){
        $emissionRange = 3;
    }
    else{echo "你的分數壞去了@@";}
    switch($emissionRange){
        case 1:
            echo "你好環保！超讚！";
            break;
        case 2:
            echo "很棒了！可以再更環保！";
            break;
        case 3:
            echo "你超不環保！跟地球說對不起！！";
            break;
    }
} else {
    echo 'no input';
}
// //食物output
// for ($i = 0; $i < count($foodName); $i++) {
//     $food = $foodName[$i];
//     if (isset($_POST[$food]) && $_POST[$food] > 0) {
//         $quantity = $_POST[$food];
//         echo "飲食: " . $food . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }
// //一次性用品output
// for ($i = 0; $i < count($disposableName); $i++) {
//     $disposable = $disposableName[$i];
//     if (isset($_POST[$disposable]) && $_POST[$disposable] > 0) {
//         $quantity = $_POST[$disposable];
//         echo "一次性用品: " . $disposable . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }
// // 個人3C
// for ($i = 0; $i < count($threeCName); $i++) {
//     $threeC = $threeCName[$i];
//     if (isset($_POST[$threeC]) && $_POST[$threeC] > 0) {
//         $quantity = $_POST[$threeC];
//         echo "個人3C: " . $threeC . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }
// //交通方式
// for ($i = 0; $i < count($TrafficName); $i++) {
//     $Traffic = $TrafficName[$i];
//     if (isset($_POST[$Traffic]) && $_POST[$Traffic] > 0) {
//         $quantity = $_POST[$Traffic];
//         echo "交通方式: " . $Traffic . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }
// //家用電器
// for ($i = 0; $i < count($EleName); $i++) {
//     $Ele = $EleName[$i];
//     if (isset($_POST[$Ele]) && $_POST[$Ele] > 0) {
//         $quantity = $_POST[$Ele];
//         echo "家用電器: " . $Ele . "，數量: " . $quantity . "<br>";
//     }
//     // else {
//     //     echo "食物: " . $food . "，數量: nothing" . "<br>";
//     // }
// }
?>